ALTER TABLE "#__banners" ALTER COLUMN "clickurl" TYPE character varying(2048);
